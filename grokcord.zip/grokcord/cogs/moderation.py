import json
import re
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone

import discord
from discord import app_commands
from discord.ext import commands

import db

CONFIG_PATH = "config.json"


def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.cfg = load_config()
        self.pattern = self.build_pattern()
        self.history = defaultdict(lambda: deque(maxlen=30))

    def build_pattern(self):
        words = self.cfg.get("banned_words", [])
        if not words:
            return None
        joined = "|".join(re.escape(w) for w in words)
        return re.compile(rf"\b(?:{joined})\b", re.IGNORECASE)

    def is_exempt(self, member):
        perms = member.guild_permissions
        return perms.administrator or perms.manage_messages

    async def send_log(self, guild, embed):
        channel = discord.utils.get(
            guild.text_channels, name=self.cfg.get("log_channel_name", "mod-logs")
        )
        if channel:
            try:
                await channel.send(embed=embed)
            except discord.Forbidden:
                pass

    def check_spam(self, message):
        spam = self.cfg["spam"]
        key = (message.guild.id, message.author.id)
        now = time.time()
        hist = self.history[key]
        hist.append((now, message.content))

        # drop old messages outside the window
        recent = [(t, c) for t, c in hist if now - t <= spam["interval_seconds"]]
        hist.clear()
        hist.extend(recent)

        if len(recent) > spam["max_messages"]:
            return "Message flooding"
        same = sum(1 for _, c in recent if c and c == message.content)
        if same >= spam["max_duplicates"]:
            return "Repeated messages"
        if len(message.mentions) >= spam["max_mentions"]:
            return "Mass mentions"
        return None

    async def punish(self, message, reason):
        member = message.author
        guild = message.guild

        try:
            await message.delete()
        except (discord.Forbidden, discord.NotFound):
            pass

        total = db.add_strike(guild.id, member.id, reason)
        limit = self.cfg["strikes_before_mute"]
        muted = False

        if total >= limit:
            try:
                await member.timeout(
                    timedelta(minutes=self.cfg["mute_minutes"]),
                    reason=f"Auto-mute: {reason}",
                )
                muted = True
                db.clear_strikes(guild.id, member.id)
            except discord.Forbidden:
                pass  # bot role is probably below theirs

        if muted:
            note = f"{member.mention} removed: {reason}. Muted for {self.cfg['mute_minutes']} min."
        else:
            note = f"{member.mention} removed: {reason}. Strike {total}/{limit}."
        try:
            await message.channel.send(note, delete_after=8)
        except discord.Forbidden:
            pass

        embed = discord.Embed(
            title="Auto-mod action",
            color=discord.Color.red() if muted else discord.Color.orange(),
            timestamp=datetime.now(timezone.utc),
        )
        embed.add_field(name="User", value=f"{member} ({member.id})", inline=False)
        embed.add_field(name="Reason", value=reason)
        embed.add_field(name="Action", value="Muted" if muted else f"Strike {total}/{limit}")
        embed.add_field(name="Channel", value=message.channel.mention)
        await self.send_log(guild, embed)

    @commands.Cog.listener()
    async def on_message(self, message):
        # ignore bots, DMs and mods
        if message.author.bot or not message.guild:
            return
        if not isinstance(message.author, discord.Member) or self.is_exempt(message.author):
            return

        if self.pattern and self.pattern.search(message.content):
            await self.punish(message, "Banned keyword")
            return

        reason = self.check_spam(message)
        if reason:
            self.history[(message.guild.id, message.author.id)].clear()
            await self.punish(message, reason)

    @app_commands.command(name="warnings", description="Show a member's strikes")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.guild_only()
    async def warnings(self, interaction: discord.Interaction, member: discord.Member):
        rows = db.get_strikes(interaction.guild.id, member.id)
        if not rows:
            await interaction.response.send_message(f"{member} has no strikes.", ephemeral=True)
            return
        lines = [f"<t:{ts}:R> - {reason}" for reason, ts in rows[:10]]
        await interaction.response.send_message(
            f"**{member}** has {len(rows)} strike(s):\n" + "\n".join(lines), ephemeral=True
        )

    @app_commands.command(name="clearwarnings", description="Clear a member's strikes")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.guild_only()
    async def clearwarnings(self, interaction: discord.Interaction, member: discord.Member):
        db.clear_strikes(interaction.guild.id, member.id)
        await interaction.response.send_message(f"Cleared strikes for {member}.", ephemeral=True)

    @app_commands.command(name="mute", description="Timeout a member")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.guild_only()
    async def mute(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        minutes: app_commands.Range[int, 1, 40320] = 10,
        reason: str = "No reason given",
    ):
        try:
            await member.timeout(timedelta(minutes=minutes), reason=reason)
        except discord.Forbidden:
            await interaction.response.send_message(
                "Can't mute them, my role needs to be higher.", ephemeral=True
            )
            return
        await interaction.response.send_message(f"Muted {member.mention} for {minutes} min.")

    @app_commands.command(name="unmute", description="Remove a member's timeout")
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.guild_only()
    async def unmute(self, interaction: discord.Interaction, member: discord.Member):
        await member.timeout(None)
        await interaction.response.send_message(f"Unmuted {member.mention}.")

    @app_commands.command(name="addword", description="Add a banned word")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def addword(self, interaction: discord.Interaction, word: str):
        word = word.lower().strip()
        if word and word not in self.cfg["banned_words"]:
            self.cfg["banned_words"].append(word)
            save_config(self.cfg)
            self.pattern = self.build_pattern()
        await interaction.response.send_message("Added.", ephemeral=True)

    @app_commands.command(name="removeword", description="Remove a banned word")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def removeword(self, interaction: discord.Interaction, word: str):
        word = word.lower().strip()
        if word in self.cfg["banned_words"]:
            self.cfg["banned_words"].remove(word)
            save_config(self.cfg)
            self.pattern = self.build_pattern()
        await interaction.response.send_message("Removed.", ephemeral=True)


async def setup(bot):
    await bot.add_cog(Moderation(bot))
