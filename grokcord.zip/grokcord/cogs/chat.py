import json

import discord
from discord import app_commands
from discord.ext import commands

import db
from grok_client import GrokError


def split_text(text, size=1900):
    # discord caps messages at 2000 chars
    parts = []
    while len(text) > size:
        cut = text.rfind("\n", 0, size)
        if cut < size // 2:
            cut = size
        parts.append(text[:cut])
        text = text[cut:].lstrip("\n")
    parts.append(text)
    return parts


class Chat(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        with open("config.json", "r", encoding="utf-8") as f:
            self.history_limit = json.load(f)["history_messages"]

    @app_commands.command(name="chat", description="Talk to Grok")
    @app_commands.describe(message="What do you want to say?")
    async def chat(self, interaction: discord.Interaction, message: str):
        await interaction.response.defer(thinking=True)

        channel_id = interaction.channel_id
        user_id = interaction.user.id

        history = db.get_history(channel_id, user_id, self.history_limit)
        history.append({"role": "user", "content": message})

        try:
            reply = await self.bot.grok.ask(history)
        except GrokError as err:
            await interaction.followup.send(f"Something went wrong: {err}")
            return

        # only save the turn once Grok actually answered
        db.add_message(channel_id, user_id, "user", message)
        db.add_message(channel_id, user_id, "assistant", reply)

        parts = split_text(reply)
        await interaction.followup.send(
            parts[0], allowed_mentions=discord.AllowedMentions.none()
        )
        for part in parts[1:]:
            await interaction.followup.send(
                part, allowed_mentions=discord.AllowedMentions.none()
            )

    @app_commands.command(name="reset", description="Forget our conversation in this channel")
    async def reset(self, interaction: discord.Interaction):
        db.clear_history(interaction.channel_id, interaction.user.id)
        await interaction.response.send_message("Conversation cleared.", ephemeral=True)


async def setup(bot):
    await bot.add_cog(Chat(bot))
